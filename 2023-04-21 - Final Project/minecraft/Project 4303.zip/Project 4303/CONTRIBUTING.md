Please contact **Blinkenlights** or **Nils** via [**#gdmc-http-discussion-help on the GDMC Discord**](https://discord.gg/zkdaEMBCmd) if you are interested in contributing!
