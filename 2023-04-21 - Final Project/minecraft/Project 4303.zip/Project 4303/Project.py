#! /usr/bin/python3

__all__ = []

# __version__

from random import randint

from gdpc import geometry as GEO
from gdpc import interface as INTF
from gdpc import toolbox as TB
from gdpc import worldLoader as WL
import random
import time
import math

from AStar import Algorithm




STARTX, STARTY, STARTZ, ENDX, ENDY, ENDZ = INTF.requestBuildArea()  # BUILDAREA


WORLDSLICE = WL.WorldSlice(STARTX, STARTZ,
                           ENDX + 1, ENDZ + 1)

ROADHEIGHT = 0

doorLocations = []
doorLocations2 = []
wallsTextures = ["white_concrete"]
roofTextures = ["birch_wood","dark_oak_wood","acacia_wood"]
borderTextures = ["lime_concrete"]


#method to Build Church Roof
def buildChurchRoof(x, y, z, radius, roof_material):
    # Define dimensions for the roof
    roof_length = radius * 2 + 1
    roof_width = radius * 2 + 1
    roof_height = radius

    # creating the Pyramid type shape
    for i in range(roof_height):
        # Calculate the current layer dimensions
        layer_length = roof_length - i * 2
        layer_width = roof_width - i * 2

        # Placing a flat layer of the roof
        GEO.placeCuboid(
            x - layer_length // 2,
            y + i,
            z - layer_width // 2,
            x + layer_length // 2,
            y + i,
            z + layer_width // 2,
            roof_material,
        )

        # Adding air blocks inside the roof to make it hollow
        if i < roof_height - 1:
            GEO.placeCuboid(
                x - layer_length // 2 + 1,
                y + i + 1,
                z - layer_width // 2 + 1,
                x + layer_length // 2 - 1,
                y + i + 1,
                z + layer_width // 2 - 1,
                "air",
            )

churchDoor = ()

#method to create Windows and doors of the church
def addChurchWindowsAndDoors(x, y, z, radius, height, window_material, door_material):
    door_height = 2

    # Add the main door
    INTF.placeBlock(x + radius, y + 1, z, door_material)
    INTF.placeBlock(x + radius, y + 2, z, f"{door_material}[facing=west, half=upper]")
    churchDoor = (x - radius, z)

    # Add windows on the north, south, east, and west walls
    window_y_start = y + 3
    window_y_end = y + height - 2
    window_positions = [
        (x - radius, z),  # West wall
        (x + radius, z),  # East wall
        (x, z - radius),  # North wall
        (x, z + radius),  # South wall
    ]

    for wx, wz in window_positions:
        for wy in range(window_y_start, window_y_end, 3):
            GEO.placeCuboid(wx, wy, wz, wx, wy + 1, wz, window_material)


def addChurchInterior(x, y, z, radius, height):
    # Add flooring
    GEO.placeCenteredCylinder(x, y - 1, z, 1, radius, "polished_andesite")

    #addinga  benches to sit inside the church
    pew_material = "dark_oak_stairs"
    pew_positions = [
        (x - radius + 2, z - 1),
        (x - radius + 2, z + 1),
        (x + radius - 2, z - 1),
        (x + radius - 2, z + 1),
    ]

    for px, pz in pew_positions:
        for offset in range(1, radius - 1):
            INTF.placeBlock(px, y, pz + offset, f"{pew_material}[facing=south]")
            INTF.placeBlock(px, y, pz - offset, f"{pew_material}[facing=north]")

    # Adding an altar inside the church
    altar_material = "polished_andesite_slab"
    GEO.placeCuboid(x - 1, y, z - radius + 1, x + 1, y, z - radius + 3, altar_material)

    cross_material = "minecraft:gold_block"
    GEO.placeCuboid(x, y + 1, z - radius + 2, x, y + 4, z - radius + 2, cross_material)
    GEO.placeCuboid(x - 1, y + 3, z - radius + 2, x + 1, y + 3, z - radius + 2, cross_material)

    # adding torches on the walls of the church
    torch_positions = [
        (x - radius, y + 2, z - radius + 1),
        (x - radius, y + 2, z + radius - 1),
        (x + radius, y + 2, z - radius + 1),
        (x + radius, y + 2, z + radius - 1),
    ]

    for tx, ty, tz in torch_positions:
        INTF.placeBlock(tx, ty+1, tz, "wall_torch[facing=west]")


#Building the church---------------------------------------------------------------------------------------------------
def buildChurch(x, z):
    # Constants
    radius = 5

    heights = WORLDSLICE.heightmaps["MOTION_BLOCKING_NO_LEAVES"]

    y = heights[(x,z)] - 2
    height = 15


    print(f"Building church at {x}, {z}...")
    # checking if the area is suitable for building
    #if not checkAreaForBuilding(x, z, radius):
        #return

    clearVolume(x-radius*2,y,z-radius*2,x+radius*2,y+height+2,z+radius*2,clearAll=True)

    # Build the base of the church
    GEO.placeCenteredCylinder(x, y, z, 1, radius, "minecraft:oak_planks")

    # Build the walls of the church
    GEO.placeCenteredCylinder(x, y + 1, z, height, radius, "minecraft:white_concrete", tube=True)

    # Build the roof
    buildChurchRoof(x, y + height, z, radius, "minecraft:gray_concrete")

    # Add windows and doors
    addChurchWindowsAndDoors(x, y, z, radius, height, "glass_pane", "oak_door")

    # Add interior details
    addChurchInterior(x, y + 1, z, radius, height)

#Houses-------------------------------------------------------------------------------------------------
def addHutWindowsAndDoors(x, y, z, radius, height, window_material, door_material,ival):
    door_height = 2

    #west = x-radius, z
    #north = x,z-radius
    #south = x,z+radius
    #east = x+radius,z

    if(ival == 0):

        # adding the main door, open
        INTF.placeBlock(x, y + 1, z+radius, f"{door_material}[facing=west, open=true]")
        INTF.placeBlock(x, y + 2, z+radius, f"{door_material}[facing=west, half=upper, open=true]")
        doorLocations.append((x,z+radius))

        window_y_start = y + 2
        window_positions = [
            (x - radius, z),  # west wall
            (x, z - radius),  # north wall
            (x + radius, z),  # East wall
        ]

        for wx, wz in window_positions:
            INTF.placeBlock(wx, window_y_start, wz, window_material)

    else:

        # adding the main door, open
        INTF.placeBlock(x, y + 1, z - radius, f"{door_material}[facing=west, open=true]")
        INTF.placeBlock(x, y + 2, z - radius, f"{door_material}[facing=west, half=upper, open=true]")
        doorLocations2.append((x, z - radius))

        # Add windows on the all sides (north, south, east, and west) of the walls
        window_y_start = y + 2
        window_positions = [
            (x - radius, z),  # west wall
            (x, z + radius),  # South wall
            (x + radius, z),  # East wall
        ]

        for wx, wz in window_positions:
            INTF.placeBlock(wx, window_y_start, wz, window_material)



#adding a roof to the hut
def buildHutRoof(x, y, z, radius, roof_material):
    # Define dimensions for the roof
    roof_length = radius * 2 + 1
    roof_width = radius * 2 + 1
    roof_height = radius // 2

    # Create the roof shape
    for i in range(roof_height):
        # Calculate the current layer dimensions
        layer_length = roof_length - i * 2
        layer_width = roof_width - i * 2

        # Place the current layer of the roof
        GEO.placeCuboid(
            x - layer_length // 2,
            y + i,
            z - layer_width // 2,
            x + layer_length // 2,
            y + i,
            z + layer_width // 2,
            roof_material,
        )

        # Add air blocks inside the roof to hollow it out
        if i < roof_height - 1:
            GEO.placeCuboid(
                x - layer_length // 2 + 1,
                y + i + 1,
                z - layer_width // 2 + 1,
                x + layer_length // 2 - 1,
                y + i + 1,
                z + layer_width // 2 - 1,
                "air",
            )


#building a fence around every house depending on it's dimensions
def buildFence(x, z, fence_radius):
    fence_material = "jungle_fence"

    heights = WORLDSLICE.heightmaps["MOTION_BLOCKING_NO_LEAVES"]

    for angle in range(0, 360, 5):
        rad_angle = math.radians(angle)
        x_offset = int(fence_radius * math.cos(rad_angle))
        z_offset = int(fence_radius * math.sin(rad_angle))
        fence_x = x + x_offset
        fence_z = z + z_offset

        y_value = heights[(fence_x,fence_z)]
        if y_value is not None:
            INTF.placeBlock(fence_x, y_value, fence_z, fence_material)
#interior decorations: Adding torches on the walls of the houses
def addWallTorches(x, y, z, radius, height, wall_torch_block):
    torch_positions = [
        (x - radius + 1, y + height // 2, z),
        (x + radius - 1, y + height // 2, z),
        (x, y + height // 2, z - radius + 1),
        (x, y + height // 2, z + radius - 1)
    ]

    for torch_x, torch_y, torch_z in torch_positions:
        INTF.placeBlock(torch_x, torch_y, torch_z, wall_torch_block)

def addBedAtCorner(x, y, z, radius, bed_block):


    offset = 1

    cX = x - radius + 1 + offset
    cY = y + 1
    cZ = z - radius + offset

    INTF.placeBlock(cX, cY, cZ, bed_block)


def buildHut(x, z,ival):
    # Constants
    radius = 3
    fence_offset = 3
    heights = WORLDSLICE.heightmaps["MOTION_BLOCKING_NO_LEAVES"]
    z = random.randrange(z-5,z+5+1)
    y = heights[(x, z)] - 1

    height = 4

    values = ["oak_planks","minecraft:spruce_planks","minecraft:birch_planks","minecraft:acacia_planks","minecraft:jungle_planks"]

    print(f"Building hut at {x}, {z}...")
    # Checking if the area is suitable for building
    #if not checkAreaForBuilding(x, z, radius):
        #return
    clearVolume(x-radius,y,z-radius,x+radius,y+height+2,z+radius,True)

    col = random.choice(values)

    # base of the hut
    GEO.placeCenteredCylinder(x, y, z, 1, radius, col)



    # Build the walls of the hut
    GEO.placeCenteredCylinder(x, y + 1, z, height, radius, col, tube=True)

    # Build the roof
    buildHutRoof(x, y + height, z, radius, col)

    # Add windows and doors
    addHutWindowsAndDoors(x, y, z, radius, height, "glass_pane", "oak_door",ival)

    # Add wall torches inside the hut on two sides
    addWallTorches(x, y, z, radius, height, "minecraft:wall_torch")

    bookshelf = ["minecraft:bookshelf"]

    for i in range(3):
        if ival == 0:
            addBedAtCorner(x+i,y,z,radius,random.choice(bookshelf))
        else:
            addBedAtCorner(x + i, y, z+4, radius, random.choice(bookshelf))



    fence_radius = radius + fence_offset

    buildFence(x, z, fence_radius)


#FARM--------------------------------------------------------------------------------------------------------------------

def buildFarm(x, z):
    farm_size = 40

    heights = WORLDSLICE.heightmaps["MOTION_BLOCKING_NO_LEAVES"]

    y = heights[(x, z)] - 1

    fence_height = 1

    print(f"Building farm at {x}, {z}...")



    # Creating the boundary of the farm using oak type fences
    for i in range(farm_size + 1):
        if i != farm_size // 2:  # Leave an opening for entrance

            yy1 = heights[(x-farm_size//2, z-farm_size//2+i)]
            yy2 = heights[(x + farm_size // 2,z - farm_size // 2 + i)]
            yy3 = heights[(x - farm_size // 2 + i,z - farm_size // 2)]
            yy4 = heights[(x - farm_size // 2 + i, z + farm_size // 2)]

            INTF.placeBlock(x - farm_size // 2, yy1, z - farm_size // 2 + i, "oak_fence")
            INTF.placeBlock(x + farm_size // 2, yy2, z - farm_size // 2 + i, "oak_fence")
            INTF.placeBlock(x - farm_size // 2 + i, yy3, z - farm_size // 2, "oak_fence")
            INTF.placeBlock(x - farm_size // 2 + i, yy4, z + farm_size // 2, "oak_fence")

    # Placing random plants, grass, and flowers within the boundary
    plants = ["wheat", "carrots", "potatoes", "beetroots", "grass", "poppy", "dandelion"]
    for i in range(-farm_size // 2 + 1, farm_size // 2):
        for j in range(-farm_size // 2 + 1, farm_size // 2):
            random_plant = random.choice(plants)

            if random_plant == "grass" or random_plant == "poppy" or random_plant == "dandelion":

                yy1 = heights[(x+i,z+j)]


                INTF.placeBlock(x + i, yy1, z + j, "grass_block")
                INTF.placeBlock(x + i, yy1 + 1, z + j, random_plant)
            else:
                INTF.placeBlock(x + i, yy1, z + j, "farmland")
                INTF.placeBlock(x + i, yy1 + 1, z + j, f"{random_plant}")




def buildPerimeter():

    heights = WORLDSLICE.heightmaps["MOTION_BLOCKING_NO_LEAVES"]

    print("Building east-west walls...")
    # building the east-west walls

    for x in range(STARTX, ENDX + 1):
        # the northern wall
        y = heights[(x, STARTZ)]
        GEO.placeCuboid(x, y - 2, STARTZ, x, y, STARTZ, "sandstone")
        GEO.placeCuboid(x, y + 1, STARTZ, x, y + 4, STARTZ, "sandstone_wall")

        # the southern wall
        y = heights[(x, ENDZ)]
        GEO.placeCuboid(x, y - 2, ENDZ, x, y, ENDZ, "sandstone")
        GEO.placeCuboid(x, y + 1, ENDZ, x, y + 4, ENDZ, "sandstone_wall")

    print("Building north-south walls...")
    # building the north-south walls
    for z in range(STARTZ, ENDZ + 1):
        # the western wall
        y = heights[(STARTX, z)]
        GEO.placeCuboid(STARTX, y - 2, z, STARTX, y, z, "sandstone")
        GEO.placeCuboid(STARTX, y + 1, z, STARTX, y + 4, z, "sandstone_wall")
        # the eastern wall
        y = heights[(ENDX, z)]
        GEO.placeCuboid(ENDX, y - 2, z, ENDX, y, z, "sandstone")
        GEO.placeCuboid(ENDX, y + 1, z, ENDX, y + 4, z, "sandstone_wall")



def clearVolume(x1, y1, z1, x2, y2, z2, clearAll = False):
    blocks_to_clear = {
        "minecraft:dark_oak_leaves",
        "minecraft:birch_leaves",
        "minecraft:dark_oak_log",
        "minecraft:oak_leaves",
        "minecraft:oak_log",
        "minecraft:birch_log",
    }

    for x in range(min(x1, x2), max(x1, x2) + 1):
        for y in range(min(y1, y2), max(y1, y2) + 1):
            for z in range(min(z1, z2), max(z1, z2) + 1):

                if(clearAll):
                    INTF.placeBlock(x, y, z, "minecraft:air")

                else:

                    block = INTF.getBlock(x, y, z)
                    if block in blocks_to_clear:
                        INTF.placeBlock(x, y, z, "minecraft:air")


def placeTree(x, y, z):
    tree_types = [
        ("oak_log", "oak_leaves"),
        ("birch_log", "birch_leaves"),
        ("dark_oak_log", "dark_oak_leaves"),
    ]

    log,leaves = tree_types[randint(0, len(tree_types) - 1)]

    # placing the log
    for i in range(4):
        INTF.placeBlock(x, y + i, z, f"minecraft:{log}")

    # placing the leaves
    for dx in range(-1, 2):
        for dz in range(-1, 2):
            if dx != 0 or dz != 0:
                INTF.placeBlock(x + dx, y + 3, z + dz, f"minecraft:{leaves}")

    # placing additional leaves on top
    INTF.placeBlock(x, y + 4, z, f"minecraft:{leaves}")


def buildDirtRoad(x1, z1, x2, z2, tree_interval):

    heights = WORLDSLICE.heightmaps["MOTION_BLOCKING_NO_LEAVES"]
    ymin = heights[x1,z1]

    clearVolume(x1,ymin,z1,x2,ymin+20,z2)

    for x in range(min(x1, x2), max(x1, x2) + 1):
        for z in range(min(z1, z2), max(z1, z2) + 1):

            y = heights[(x,z)] - 1

            # Place dirt for the road
            INTF.placeBlock(x, y, z, "minecraft:dirt")
            GEO.placeCenteredCylinder(x, y + 1, z, 1, 1, "air")

            # Place trees in the middle at specified intervals
            if (x - x1) % tree_interval == 0 and (z - z1) % tree_interval == 0:
                placeTree(x, y + 1, z)



def buildSettlement(x, z):
    doorsArray = []
    hut_spacing = 15
    between_rows = 35

    for i in range(2):
        for j in range(5):
            hut_x = x + j * hut_spacing
            hut_z = z + i * between_rows
            buildHut(hut_x, hut_z,i)

            door_x = hut_x - 2
            door_y = ROADHEIGHT + 1
            door_z = hut_z

            if i == 1:
                door_x += 4

            doorsArray.append((door_x, door_y, door_z))

    return doorsArray


# Building watch towers on each corner of the settlement
def buildWatchtower(x, z):
    # Constants
    wall_height = 20
    balcony_height = 2

    # Ground level
    y = WORLDSLICE.heightmaps["MOTION_BLOCKING_NO_LEAVES"][(x, z)] - 1

    # Build the base
    for dx in range(-1, 2):
        for dz in range(-1, 2):
            INTF.placeBlock(x + dx, y, z + dz, "minecraft:blackstone")

    # Build the walls
    for i in range(wall_height):
        for dx in range(-1, 2):
            for dz in range(-1, 2):
                if dx != 0 or dz != 0:
                    INTF.placeBlock(x + dx, y + 1 + i, z + dz, "minecraft:blackstone")

    # Special Feature: ladder
    for i in range(wall_height):
        INTF.placeBlock(x, y + 1 + i, z - 1, "ladder[facing=north]")

    # Adding a door at the bottom
    INTF.placeBlock(x, y + 1, z - 1, "oak_door[facing=north]")
    INTF.placeBlock(x, y + 2, z - 1, "oak_door[facing=north, half=upper]")
    

    # Opening in the wall for access to the top platform
    INTF.placeBlock(x + 1, y + wall_height - 1, z, "air")
    INTF.placeBlock(x + 1, y + wall_height - 2, z, "air")

    # flooring for the top platform
    for dx in range(-1, 2):
        for dz in range(-1, 2):
            INTF.placeBlock(x + dx, y + wall_height, z + dz, "stone_bricks")

    # adding balcony structure for the watch location
    for dx in range(-2, 3):
        for dz in range(-2, 3):
            if (dx == -2 or dx == 2 or dz == -2 or dz == 2) and (dx != 0 or dz != 0):
                INTF.placeBlock(x + dx, y + wall_height, z + dz, "stone_bricks")
                INTF.placeBlock(x + dx, y + wall_height + 1, z + dz, "oak_fence")


def makePath():
    heights = WORLDSLICE.heightmaps["MOTION_BLOCKING_NO_LEAVES"]

    while len(doorLocations) > 0:
        door1Index = random.randrange(0, len(doorLocations))
        door1 = doorLocations.pop(door1Index)

        door2Index = random.randrange(0, len(doorLocations2))
        door2 = doorLocations2.pop(door2Index)

        star = Algorithm.aStar(door1, door2)

        for i in range(len(star)):
            element = star[i]
            elementX = element[0]
            elementY = element[1]
            elementHeight = heights[(elementX, elementY)]
            elementHeight2 = heights[(elementX-1, elementY+1)]
            INTF.placeBlock(elementX, elementHeight-1, elementY, "spruce_wood")
            INTF.placeBlock(elementX-1, elementHeight2 - 1, elementY+1, "spruce_wood")

# building a Well near the location of the farm
def buildWell(x, y, z):
    # Build the base
    for dx in range(-2, 3):
        for dz in range(-2, 3):
            INTF.placeBlock(x + dx, y, z + dz, "minecraft:gray_concrete")

    # building the corners and walls
    for dy in range(1, 4):
        for dx, dz in [(-2, -2), (2, -2), (-2, 2), (2, 2)]:
            INTF.placeBlock(x + dx, y + dy, z + dz, "minecraft:white_concrete")
        if dy == 1:
            for dx, dz in [(-2, 0), (2, 0), (0, -2), (0, 2)]:
                INTF.placeBlock(x + dx, y + dy, z + dz, "minecraft:white_concrete")

    # Adding water here: Still water since regular water overflows
    for dx in range(-1, 2):
        for dz in range(-1, 2):
            INTF.placeBlock(x + dx, y + 1, z + dz, "minecraft:still_water")

    # building the roof to hold the water bucket
    for dx, dz in [(-2, -1), (2, -1), (-2, 1), (2, 1), (-1, -2), (1, -2), (-1, 2), (1, 2)]:
        INTF.placeBlock(x + dx, y + 4, z + dz, "minecraft:brown_concrete")
    INTF.placeBlock(x, y + 4, z, "minecraft:brown_concrete")

    # Add the bucket and rope
    INTF.placeBlock(x, y + 3, z, "minecraft:chain")
    INTF.placeBlock(x, y + 2, z, "minecraft:chain")
    INTF.placeBlock(x, y + 1, z, "minecraft:cauldron[level=3]")





def startCreating():
    heights = WORLDSLICE.heightmaps["MOTION_BLOCKING_NO_LEAVES"]


    buildPerimeter()

    buildFarm(90, 95)
    #fixed locations of the watch towers
    buildWatchtower(123, 123)
    buildWatchtower(123, 5)
    buildWatchtower(5, 5)
    buildWatchtower(5, 123)

    buildWell(60,heights[(60,85)]-1,85)

    settlementX = 50
    settlementZ = 25
    buildChurch(30, 95)

    buildSettlement(settlementX, settlementZ)
    makePath()

    buildDirtRoad(settlementX - 10, settlementZ + 15, settlementX + 70, settlementZ + 25, 10)

#main function
if __name__ == '__main__':

    Heights = WORLDSLICE.heightmaps["MOTION_BLOCKING_NO_LEAVES"]
    INTF.runCommand(f"tp @a {STARTX} {Heights} {STARTZ}")

    startCreating()







