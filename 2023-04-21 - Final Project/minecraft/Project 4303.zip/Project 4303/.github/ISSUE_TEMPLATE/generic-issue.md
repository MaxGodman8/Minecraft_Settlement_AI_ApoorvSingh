---
name: Generic issue
about: Describe this issue template's purpose here.
title: ''
labels: ''
assignees: Flashing-Blinkenlights

---

**Feature branch: `None`**

Your suggestion here.

### Suggested implementation:

```py
def what_I_imagine():
    ...
```

Pro:
- [fill me]

Con:
- [fill me]
