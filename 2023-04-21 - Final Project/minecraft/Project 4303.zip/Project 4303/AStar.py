from warnings import warn
import heapq
from gdpc import geometry as GEO
from gdpc import interface as INTF
from gdpc import toolbox as TB
from gdpc import worldLoader as WL


class Algorithm:

    def aStar(start, end, diagonal=False):

        STARTX, STARTY, STARTZ, ENDX, ENDY, ENDZ = INTF.requestBuildArea()  # BUILDAREA
        WORLDSLICE = WL.WorldSlice(STARTX, STARTZ,
                                   ENDX + 1, ENDZ + 1)  # this takes a while

        # calculate a heightmap suitable for building:
        #heightmap = mapUtils.calcGoodHeightmap(worldSlice)

        heightmap = WORLDSLICE.heightmaps["MOTION_BLOCKING_NO_LEAVES"]

        # Create start and end node
        begNode = Node(None, start)
        begNode.g = 0
        begNode.h = 0
        begNode.f = 0
        lastNode = Node(None, end)
        lastNode.g = 0
        lastNode.h = 0
        lastNode.f = 0
        openList = []
        closedList = []
        heapq.heapify(openList)
        heapq.heappush(openList, begNode)
        adjacent_squares = ((0, -1), (0, 1), (-1, 0), (1, 0),)
        if diagonal:
            adjacent_squares = ((0, -1), (0, 1), (-1, 0), (1, 0), (-1, -1), (-1, 1), (1, -1), (1, 1),)
        while len(openList) > 0:
            current_node = heapq.heappop(openList)
            closedList.append(current_node)
            if current_node == lastNode:

                finalPath = []

                current = current_node

                while current is not None:
                    finalPath.append(current.position)

                    current = current.parent

                return finalPath[::-1]  # Return reversed path

            # Generating the neighboring children
            children = []
            for new_position in adjacent_squares:  # Adjacent squares

                # Getting node position
                node_position = (current_node.position[0] + new_position[0], current_node.position[1] + new_position[1])
                x = node_position[0]
                z = node_position[1]
                y = heightmap[x, z] - 1
                if INTF.getBlock(x, y, z) in checkElementsArray:
                    print("Obstacle, Avoid")

                    continue

                new_node = Node(current_node, node_position)
                children.append(new_node)

            for child in children:
                # Child is in the closed list, so no need to expand again
                if len([closed_child for closed_child in closedList if closed_child == child]) > 0:
                    continue
                child.g = current_node.g + 1
                child.h = ((child.position[0] - lastNode.position[0]) ** 2) + (
                        (child.position[1] - lastNode.position[1]) ** 2)
                child.f = child.g + child.h

                if len([open_node for open_node in openList if
                        child.position == open_node.position and child.g > open_node.g]) > 0:
                    continue
                heapq.heappush(openList, child)

        warn("no path found")
        # return None
class Node:

    def __init__(self, parent=None, position=None):
        self.parent = parent
        self.position = position

        self.g = 0
        self.h = 0
        self.f = 0

    def __eq__(self, other):
        return self.position == other.position

    def __repr__(self):
        return f"{self.position} - g: {self.g} h: {self.h} f: {self.f}"

    def __lt__(self, other):
        return self.f < other.f

    def __gt__(self, other):
        return self.f > other.f
checkElementsArray = ["minecraft:white_concrete", "minecraft:lime_concrete", "minecraft:red_concrete"]